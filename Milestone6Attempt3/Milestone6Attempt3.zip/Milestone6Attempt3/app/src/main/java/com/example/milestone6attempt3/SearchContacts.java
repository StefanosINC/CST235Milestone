package com.example.milestone6attempt3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class SearchContacts extends AppCompatActivity {

    AddressBook theList;
    AddressBook searchList;
    AddressBookAdapaterAndroid adapter;


    ListView lv_contactsSearched;

    Button btn_search, btn_cancle;
    EditText txt_searchText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_contacts);

    }
};
