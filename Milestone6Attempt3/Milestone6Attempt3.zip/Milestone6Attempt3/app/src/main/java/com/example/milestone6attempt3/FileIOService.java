package com.example.milestone6attempt3;
//
//public class FileIOService implements DataAccessService {
//
//	public ContactAppBusinessService readAllData() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public boolean writeAllData(ContactAppBusinessService contactApp) {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//}
